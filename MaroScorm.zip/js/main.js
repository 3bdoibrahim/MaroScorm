$(function() {
   'use strict';
    
    // loading
      
       $(window).load(function () {
           
           $('.load').fadeOut(1000);
             $('body').css('overflow','auto')  ;
    
           
       })
         

    // Nice Scroll
    $('html').niceScroll();
    
    //Start Nav
    $('.navbar ul li').on('click',function() {
        
        $(this).addClass('active').siblings().removeClass('active');
    });
    // Start Slider
    var winh = $(window).height(),
        upperh = $('.upper-bar').innerHeight(),
        navh = $('.navbar').innerHeight();
    $('.slider .first-img').height(winh - (upperh + navh ));
    // End Slider
    // start feat 
     $('.feat ul li').on('click', function() {
         $(this).addClass('active').siblings().removeClass('active');
         if($(this).data('class') === 'all' ){
             $('.shattle-imgs .col-md').css('opacity',1);
         } else {
             $('.shattle-imgs .col-md').css('opacity','0.4');
             $($(this).data('class')).parent().css('opacity',1);
             
         }
     });
    // End Feat
    // loading page
    //Scroll
    var ScrollTop = $('.scroll');
    
    $(window).scroll(function () {
        
      if ($(this).scrollTop() >= 600) {
          
        
          $(ScrollTop).show()
      } else
          {
              $(ScrollTop).hide()
          }
        
        ScrollTop.on('click' , function () {
            
        $('html').animate({ 
            
            
            scrollTop : 0
        
        
        
        }, 800);
        
            
            
        });
        
        
    });
    
  
});